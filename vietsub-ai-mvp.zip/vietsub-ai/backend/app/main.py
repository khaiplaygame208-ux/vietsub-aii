import asyncio
import json
import logging
import mimetypes
import re
import shutil
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from .config import settings
from .models import EditSegmentsRequest, JobStatus, RenderRequest, SubtitleSegment
from .services.media import MediaError, extract_audio, probe_video
from .services.subtitles import render_video, write_subtitle_files, to_srt
from .services.transcription import transcribe_chinese
from .services.translation import TranslationError, translate_segments
from .state import all_jobs, create_job, get_job, update_job, utc_now

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("vietsub-ai")

ALLOWED_EXTENSIONS = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}
FILE_KEYS = {
    "video": "vietsub.mp4",
    "srt": "vietnamese.srt",
    "vtt": "vietnamese.vtt",
    "transcript": "transcript.txt",
    "json": "transcript.json",
}


def _job_dir(job_id: str) -> Path:
    return settings.data_path / job_id


def _must_job(job_id: str) -> dict[str, Any]:
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Không tìm thấy tác vụ hoặc tác vụ đã hết hạn.")
    return job


def _check_cancelled(job_id: str) -> bool:
    job = get_job(job_id)
    return not job or bool(job.get("cancel_requested")) or job.get("status") == "cancelled"


def _clean_expired() -> None:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=settings.job_retention_hours)
    for job in all_jobs():
        updated = job.get("updated_at") or job.get("created_at")
        if updated and updated < cutoff:
            shutil.rmtree(_job_dir(job["id"]), ignore_errors=True)
            update_job(job["id"], status="cancelled", stage="expired", message="Tệp tạm đã hết hạn và được xóa.")
    # Also remove orphaned directories left behind by a process restart.
    for path in settings.data_path.iterdir():
        if path.is_dir():
            try:
                if datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) < cutoff:
                    shutil.rmtree(path, ignore_errors=True)
            except OSError:
                logger.warning("Không thể dọn thư mục tạm %s", path.name)


async def _cleanup_loop() -> None:
    while True:
        await asyncio.sleep(3600)
        _clean_expired()


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.data_path.mkdir(parents=True, exist_ok=True)
    _clean_expired()
    task = asyncio.create_task(_cleanup_loop())
    yield
    task.cancel()


app = FastAPI(title="VietSub AI API", version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "gemini_configured": bool(settings.gemini_api_key.strip()),
        "gemini_model": settings.gemini_model,
        "max_upload_mb": settings.max_upload_mb,
        "whisper_model": settings.whisper_model,
        "retention_hours": settings.job_retention_hours,
    }


@app.post("/api/jobs", response_model=dict)
async def upload_video(file: UploadFile = File(...)):
    original_name = Path(file.filename or "video.mp4").name
    suffix = Path(original_name).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail="Định dạng chưa được hỗ trợ. Hãy dùng MP4, MOV, MKV, WEBM hoặc M4V.")
    job_id = uuid.uuid4().hex
    job_dir = _job_dir(job_id)
    job_dir.mkdir(parents=True, exist_ok=False)
    source_path = job_dir / f"source{suffix}"
    max_bytes = settings.max_upload_mb * 1024 * 1024
    size = 0
    try:
        with source_path.open("wb") as target:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise HTTPException(status_code=413, detail=f"Video vượt quá giới hạn {settings.max_upload_mb} MB.")
                target.write(chunk)
        if size == 0:
            raise HTTPException(status_code=400, detail="Tệp rỗng.")
        metadata = probe_video(source_path)
        if metadata["duration"] > settings.max_video_seconds:
            raise HTTPException(status_code=413, detail=f"Video dài hơn giới hạn {settings.max_video_seconds // 60} phút.")
        job = {
            "id": job_id,
            "filename": original_name,
            "source_path": str(source_path),
            "size_bytes": size,
            "duration": metadata["duration"],
            "status": "uploaded",
            "stage": "uploaded",
            "progress": 0,
            "message": "Video đã tải lên và kiểm tra thành công.",
            "error": None,
            "segments": [],
            "outputs": {},
            "options": {"bilingual": False, "font_size": 24, "font_family": "DejaVu Sans", "text_color": "#FFFFFF", "background": "box", "position": "bottom", "quality": "balanced"},
            "created_at": utc_now(),
            "updated_at": utc_now(),
            "cancel_requested": False,
        }
        create_job(job)
        return {"job_id": job_id, "filename": original_name, "size_bytes": size, "duration": metadata["duration"], "status": "uploaded"}
    except HTTPException:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise
    except MediaError as exc:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        shutil.rmtree(job_dir, ignore_errors=True)
        logger.exception("Tải/kiểm tra video thất bại")
        raise HTTPException(status_code=500, detail="Không thể kiểm tra video do lỗi máy chủ.") from exc
    finally:
        await file.close()


def run_pipeline(job_id: str, options: dict[str, Any]) -> None:
    job = get_job(job_id)
    if not job:
        return
    job_dir = _job_dir(job_id)
    source_path = Path(job["source_path"])
    try:
        if _check_cancelled(job_id):
            update_job(job_id, status="cancelled", stage="cancelled", message="Tác vụ đã bị hủy.")
            return
        update_job(job_id, status="processing", stage="extract_audio", progress=8, message="Đang trích xuất âm thanh bằng FFmpeg…", options=options)
        audio_path = job_dir / "audio.wav"
        extract_audio(source_path, audio_path, cancel_check=lambda: _check_cancelled(job_id))

        if _check_cancelled(job_id):
            update_job(job_id, status="cancelled", stage="cancelled", message="Tác vụ đã bị hủy.")
            return
        update_job(job_id, stage="transcribe", progress=15, message="Đang nhận diện lời thoại tiếng Trung…")
        def transcription_progress():
            if _check_cancelled(job_id):
                raise RuntimeError("Tác vụ đã bị hủy.")
        segments = transcribe_chinese(audio_path, progress_callback=transcription_progress)
        update_job(job_id, stage="translate", progress=45, message=f"Đã nhận diện {len(segments)} đoạn. Đang dịch bằng Gemini…", segments=segments)

        if _check_cancelled(job_id):
            update_job(job_id, status="cancelled", stage="cancelled", message="Tác vụ đã bị hủy.")
            return
        def translate_progress(fraction: float):
            if _check_cancelled(job_id):
                raise RuntimeError("Tác vụ đã bị hủy.")
            update_job(job_id, progress=45 + round(30 * fraction), message=f"Đang dịch bằng Gemini… ({round(fraction * 100)}%)")
        translated = translate_segments(segments, progress_callback=translate_progress)
        update_job(job_id, stage="subtitles", progress=78, message="Đang tạo phụ đề SRT/VTT…", segments=translated)
        srt_path, vtt_path = write_subtitle_files(job_dir, translated, options.get("bilingual", False))
        (job_dir / "transcript.txt").write_text(
            "\n".join(f"[{item['start']:.2f}-{item['end']:.2f}] 中文: {item['chinese']}\nTiếng Việt: {item['vietnamese']}" for item in translated),
            encoding="utf-8",
        )
        (job_dir / "transcript.json").write_text(json.dumps(translated, ensure_ascii=False, indent=2), encoding="utf-8")

        if _check_cancelled(job_id):
            update_job(job_id, status="cancelled", stage="cancelled", message="Tác vụ đã bị hủy.")
            return
        update_job(job_id, stage="render", progress=82, message="Đang kết xuất MP4 và ghép phụ đề…")
        def render_progress(fraction: float):
            if _check_cancelled(job_id):
                return
            update_job(job_id, progress=82 + round(17 * fraction), message=f"Đang kết xuất MP4… ({round(fraction * 100)}%)")
        output = render_video(job_dir, source_path, translated, options, float(job["duration"]),
                              cancel_check=lambda: _check_cancelled(job_id), progress_callback=render_progress)
        outputs = {"video": output.name, "srt": srt_path.name, "vtt": vtt_path.name,
                   "transcript": "transcript.txt", "json": "transcript.json"}
        update_job(job_id, status="completed", stage="completed", progress=100,
                   message="Hoàn thành. Bạn có thể xem lại phụ đề và tải kết quả.", segments=translated, outputs=outputs,
                   updated_at=utc_now())
    except Exception as exc:
        if _check_cancelled(job_id):
            update_job(job_id, status="cancelled", stage="cancelled", message="Tác vụ đã bị hủy.")
        else:
            logger.exception("Tác vụ %s thất bại", job_id)
            message = str(exc).strip() or exc.__class__.__name__
            update_job(job_id, status="failed", stage="failed", progress=0, error=message[:1200], message="Xử lý thất bại. Hãy kiểm tra cấu hình và thử lại.")


@app.post("/api/jobs/{job_id}/translate")
def start_translation(job_id: str, background_tasks: BackgroundTasks, options: RenderRequest | None = None):
    job = _must_job(job_id)
    if job["status"] in {"queued", "processing"}:
        raise HTTPException(status_code=409, detail="Tác vụ này đang được xử lý.")
    if not settings.gemini_api_key.strip():
        raise HTTPException(status_code=503, detail="Thiếu GEMINI_API_KEY. Hãy cấu hình backend/.env rồi khởi động lại máy chủ.")
    if job["status"] == "completed":
        raise HTTPException(status_code=409, detail="Tác vụ đã hoàn thành. Hãy sửa phụ đề hoặc tạo tác vụ mới.")
    opts = options.model_dump() if options else job.get("options", {})
    update_job(job_id, status="queued", stage="queued", progress=2, message="Đã đưa vào hàng xử lý…", error=None, cancel_requested=False)
    background_tasks.add_task(run_pipeline, job_id, opts)
    return {"job_id": job_id, "status": "queued", "message": "Tác vụ đã được xếp hàng."}


@app.get("/api/jobs/{job_id}", response_model=JobStatus)
def get_job_status(job_id: str):
    job = _must_job(job_id)
    return JobStatus(
        job_id=job["id"], filename=job.get("filename"), status=job["status"], stage=job["stage"], progress=job["progress"],
        message=job.get("message", ""), error=job.get("error"), duration=job.get("duration"),
        segments=job.get("segments") or None, outputs=job.get("outputs", {}),
    )


@app.put("/api/jobs/{job_id}/segments")
def save_segments(job_id: str, request: EditSegmentsRequest):
    job = _must_job(job_id)
    if job["status"] != "completed":
        raise HTTPException(status_code=409, detail="Chỉ có thể chỉnh sửa phụ đề sau khi dịch hoàn tất.")
    segments = [item.model_dump() for item in request.segments]
    duration = float(job["duration"])
    for idx, item in enumerate(segments):
        if item["end"] <= item["start"]:
            raise HTTPException(status_code=422, detail=f"Đoạn {idx + 1}: thời gian kết thúc phải lớn hơn thời gian bắt đầu.")
        if item["end"] > duration + 0.5:
            raise HTTPException(status_code=422, detail=f"Đoạn {idx + 1}: thời gian vượt quá độ dài video.")
    job_dir = _job_dir(job_id)
    write_subtitle_files(job_dir, segments, request.bilingual)
    (job_dir / "transcript.txt").write_text(
        "\n".join(f"[{item['start']:.2f}-{item['end']:.2f}] 中文: {item['chinese']}\nTiếng Việt: {item['vietnamese']}" for item in segments),
        encoding="utf-8",
    )
    (job_dir / "transcript.json").write_text(json.dumps(segments, ensure_ascii=False, indent=2), encoding="utf-8")
    options = request.model_dump(exclude={"segments"})
    update_job(job_id, segments=segments, options=options, message="Đã lưu chỉnh sửa phụ đề. Hãy kết xuất lại MP4 để áp dụng thay đổi.")
    return {"ok": True, "segments": len(segments), "message": "Đã lưu phụ đề."}


def run_render(job_id: str, options: dict[str, Any]) -> None:
    job = get_job(job_id)
    if not job:
        return
    try:
        update_job(job_id, status="processing", stage="render", progress=82, message="Đang kết xuất lại video…", options=options, error=None)
        def render_progress(fraction: float):
            if _check_cancelled(job_id):
                return
            update_job(job_id, progress=82 + round(17 * fraction), message=f"Đang kết xuất lại MP4… ({round(fraction * 100)}%)")
        output = render_video(_job_dir(job_id), Path(job["source_path"]), job.get("segments", []), options,
                              float(job["duration"]), cancel_check=lambda: _check_cancelled(job_id),
                              progress_callback=render_progress)
        update_job(job_id, status="completed", stage="completed", progress=100, outputs={**job.get("outputs", {}), "video": output.name}, message="Đã kết xuất lại MP4 với phụ đề đã chỉnh sửa.")
    except Exception as exc:
        if _check_cancelled(job_id):
            update_job(job_id, status="cancelled", stage="cancelled", message="Đã hủy kết xuất video.")
        else:
            logger.exception("Kết xuất lại thất bại cho %s", job_id)
            update_job(job_id, status="failed", stage="failed", error=str(exc)[:1200], message="Không thể kết xuất lại video.")


@app.post("/api/jobs/{job_id}/render")
def rerender(job_id: str, background_tasks: BackgroundTasks, request: RenderRequest):
    job = _must_job(job_id)
    if job["status"] != "completed":
        raise HTTPException(status_code=409, detail="Tác vụ phải hoàn thành trước khi kết xuất lại.")
    update_job(job_id, status="queued", stage="queued", progress=82, message="Đã xếp hàng kết xuất lại…")
    background_tasks.add_task(run_render, job_id, request.model_dump())
    return {"ok": True, "message": "Đang kết xuất lại video."}


@app.post("/api/jobs/{job_id}/cancel")
def cancel_job(job_id: str):
    job = _must_job(job_id)
    if job["status"] in {"completed", "failed", "cancelled"}:
        return {"ok": False, "message": "Tác vụ đã kết thúc, không thể hủy."}
    update_job(job_id, cancel_requested=True, message="Đã nhận yêu cầu hủy. Tác vụ sẽ dừng ở điểm kiểm tra tiếp theo.")
    return {"ok": True, "message": "Đã gửi yêu cầu hủy."}


@app.get("/api/jobs/{job_id}/files/{key}")
def download_file(job_id: str, key: str):
    job = _must_job(job_id)
    if key not in FILE_KEYS:
        raise HTTPException(status_code=404, detail="Loại tệp không hợp lệ.")
    filename = FILE_KEYS[key]
    path = _job_dir(job_id) / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Tệp chưa sẵn sàng hoặc đã bị xóa.")
    media_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    return FileResponse(path, media_type=media_type, filename=filename)


@app.get("/")
def root():
    return {"name": "VietSub AI", "api": "/api", "docs": "/docs"}
