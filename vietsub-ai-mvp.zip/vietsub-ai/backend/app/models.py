from typing import Literal
from pydantic import BaseModel, Field, field_validator


class SubtitleSegment(BaseModel):
    start: float = Field(ge=0)
    end: float = Field(gt=0)
    chinese: str = ""
    vietnamese: str = ""
    note: str = ""

    @field_validator("end")
    @classmethod
    def end_must_follow_start(cls, value: float, info):
        start = info.data.get("start")
        if start is not None and value <= start:
            raise ValueError("Thời gian kết thúc phải sau thời gian bắt đầu")
        return value


class JobCreateResponse(BaseModel):
    job_id: str
    filename: str
    size_bytes: int
    duration: float
    status: str


class JobStatus(BaseModel):
    job_id: str
    filename: str | None = None
    status: Literal["uploaded", "queued", "processing", "completed", "failed", "cancelled"]
    stage: str
    progress: int = Field(ge=0, le=100)
    message: str = ""
    error: str | None = None
    duration: float | None = None
    segments: list[SubtitleSegment] | None = None
    outputs: dict[str, str] = Field(default_factory=dict)


class EditSegmentsRequest(BaseModel):
    segments: list[SubtitleSegment]
    bilingual: bool = False
    font_size: int = Field(default=24, ge=12, le=60)
    font_family: Literal["DejaVu Sans", "Liberation Sans", "Noto Sans"] = "DejaVu Sans"
    text_color: str = "#FFFFFF"
    background: Literal["box", "outline"] = "box"
    position: Literal["bottom", "middle", "top"] = "bottom"
    quality: Literal["compact", "balanced", "high"] = "balanced"


class RenderRequest(BaseModel):
    bilingual: bool = False
    font_size: int = Field(default=24, ge=12, le=60)
    font_family: Literal["DejaVu Sans", "Liberation Sans", "Noto Sans"] = "DejaVu Sans"
    text_color: str = "#FFFFFF"
    background: Literal["box", "outline"] = "box"
    position: Literal["bottom", "middle", "top"] = "bottom"
    quality: Literal["compact", "balanced", "high"] = "balanced"
