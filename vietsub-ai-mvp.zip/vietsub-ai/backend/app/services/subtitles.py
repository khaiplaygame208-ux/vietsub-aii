from pathlib import Path
from .media import render_burned_subtitles


def _timestamp(seconds: float, comma: bool = True) -> str:
    total_ms = max(0, round(float(seconds) * 1000))
    hours, remain = divmod(total_ms, 3_600_000)
    minutes, remain = divmod(remain, 60_000)
    secs, ms = divmod(remain, 1000)
    sep = "," if comma else "."
    return f"{hours:02}:{minutes:02}:{secs:02}{sep}{ms:03}"


def to_srt(segments: list[dict], bilingual: bool = False) -> str:
    lines = []
    for index, segment in enumerate(segments, start=1):
        start = max(0.0, float(segment["start"]))
        end = max(start + 0.08, float(segment["end"]))
        text = segment.get("vietnamese", "").strip()
        if bilingual and segment.get("chinese", "").strip():
            text = segment["chinese"].strip() + "\n" + text
        lines.append(f"{index}\n{_timestamp(start)} --> {_timestamp(end)}\n{text}")
    return "\n\n".join(lines) + ("\n" if lines else "")


def to_vtt(segments: list[dict], bilingual: bool = False) -> str:
    srt = to_srt(segments, bilingual=bilingual)
    body = srt.replace(",", ".")
    # WebVTT cue numbers are optional; remove them to keep output simple.
    cues = []
    for block in body.strip().split("\n\n") if body.strip() else []:
        rows = block.splitlines()
        if len(rows) >= 3 and rows[0].isdigit():
            rows = rows[1:]
        cues.append("\n".join(rows))
    return "WEBVTT\n\n" + "\n\n".join(cues) + ("\n" if cues else "")


def write_subtitle_files(job_dir: Path, segments: list[dict], bilingual: bool = False) -> tuple[Path, Path]:
    srt_path = job_dir / "vietnamese.srt"
    vtt_path = job_dir / "vietnamese.vtt"
    srt_path.write_text(to_srt(segments, bilingual), encoding="utf-8-sig")
    vtt_path.write_text(to_vtt(segments, bilingual), encoding="utf-8")
    return srt_path, vtt_path


def render_video(job_dir: Path, source_video: Path, segments: list[dict], options: dict, duration: float, cancel_check=None, progress_callback=None) -> Path:
    srt_path, _ = write_subtitle_files(job_dir, segments, options.get("bilingual", False))
    output = job_dir / "vietsub.mp4"
    render_burned_subtitles(
        source_video, srt_path, output,
        font_size=int(options.get("font_size", 24)),
        font_family=options.get("font_family", "DejaVu Sans"),
        text_color=options.get("text_color", "#FFFFFF"),
        background=options.get("background", "box"),
        position=options.get("position", "bottom"),
        quality=options.get("quality", "balanced"),
        duration=duration,
        cancel_check=cancel_check,
        progress_callback=progress_callback,
    )
    return output
