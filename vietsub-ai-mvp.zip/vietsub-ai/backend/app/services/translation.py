import json
import re
import time
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from ..config import settings


class TranslatedLine(BaseModel):
    index: int = Field(ge=0)
    start: float = Field(ge=0)
    end: float = Field(gt=0)
    chinese: str
    vietnamese: str
    note: str = ""


class TranslationBatch(BaseModel):
    translations: list[TranslatedLine]


class TranslationError(RuntimeError):
    pass


def _client():
    if not settings.gemini_api_key.strip():
        raise TranslationError(
            "Chưa cấu hình GEMINI_API_KEY. Sao chép backend/.env.example thành backend/.env và điền API key từ https://aistudio.google.com/apikey."
        )
    try:
        from google import genai
    except ImportError as exc:
        raise TranslationError("Thiếu thư viện google-genai. Hãy cài backend/requirements.txt.") from exc
    return genai.Client(api_key=settings.gemini_api_key)


def _parse_output(text: str) -> dict[str, Any]:
    content = text.strip()
    content = re.sub(r"^```(?:json)?\s*", "", content, flags=re.IGNORECASE)
    content = re.sub(r"\s*```$", "", content)
    try:
        return json.loads(content)
    except json.JSONDecodeError as first_error:
        left, right = content.find("{"), content.rfind("}")
        if left >= 0 and right > left:
            try:
                return json.loads(content[left:right + 1])
            except json.JSONDecodeError:
                pass
        raise TranslationError(f"Gemini trả về JSON không hợp lệ: {first_error.msg}") from first_error


def translate_segments(segments: list[dict], progress_callback=None) -> list[dict]:
    client = _client()
    from google.genai import types
    # Small batches reduce prompt size and make retries local to a batch.
    translated: list[dict] = []
    batch_size = 25
    for offset in range(0, len(segments), batch_size):
        batch = segments[offset:offset + batch_size]
        payload = [{"index": i, "start": item["start"], "end": item["end"], "chinese": item["chinese"]} for i, item in enumerate(batch)]
        prompt = (
            "Bạn là biên dịch viên tiếng Trung sang tiếng Việt. Dịch tự nhiên, đúng ngữ cảnh, ngắn gọn để đọc phụ đề. "
            "Giữ tên riêng/thuật ngữ khi thích hợp. Không bỏ ý quan trọng, không thêm lời giải thích ngoài lề. "
            "Trả về JSON theo schema đã cung cấp; giữ nguyên index, start, end và chinese của từng mục, chỉ dịch vietnamese; mỗi index phải khớp đầu vào. Ghi chú có thể để trống.\n"
            f"Dữ liệu cần dịch:\n{json.dumps(payload, ensure_ascii=False)}"
        )
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                response = client.models.generate_content(
                    model=settings.gemini_model,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        response_mime_type="application/json",
                        response_schema=TranslationBatch,
                        temperature=0.2,
                    ),
                )
                data = _parse_output(response.text or "")
                parsed = TranslationBatch.model_validate(data)
                by_index = {line.index: line for line in parsed.translations}
                batch_results = []
                for i, source in enumerate(batch):
                    line = by_index.get(i)
                    if line is None or not line.vietnamese.strip():
                        raise TranslationError(f"Thiếu bản dịch cho câu số {offset + i + 1}.")
                    if abs(line.start - float(source["start"])) > 0.08 or abs(line.end - float(source["end"])) > 0.08:
                        raise TranslationError(f"Gemini làm thay đổi mốc thời gian của câu số {offset + i + 1}.")
                    batch_results.append({**source, "vietnamese": line.vietnamese.strip(), "note": line.note.strip()})
                translated.extend(batch_results)
                last_error = None
                break
            except (ValidationError, json.JSONDecodeError, TranslationError) as exc:
                last_error = exc
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
            except Exception as exc:
                last_error = exc
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
        if last_error:
            raise TranslationError(
                f"Không dịch được nhóm câu {offset + 1}–{offset + len(batch)} sau 3 lần thử: {str(last_error)[:400]}"
            ) from last_error
        if progress_callback:
            progress_callback(min(1.0, (offset + len(batch)) / len(segments)))
    return translated
