from pathlib import Path
from threading import Lock

from ..config import settings

_model = None
_model_lock = Lock()


def get_model():
    global _model
    with _model_lock:
        if _model is None:
            try:
                from faster_whisper import WhisperModel
            except ImportError as exc:
                raise RuntimeError("Thiếu thư viện faster-whisper. Hãy cài backend/requirements.txt.") from exc
            _model = WhisperModel(
                settings.whisper_model,
                device=settings.whisper_device,
                compute_type=settings.whisper_compute_type,
            )
        return _model


def transcribe_chinese(audio_path: Path, progress_callback=None) -> list[dict]:
    model = get_model()
    segments, info = model.transcribe(
        str(audio_path),
        language="zh",
        task="transcribe",
        vad_filter=True,
        beam_size=5,
        condition_on_previous_text=False,
    )
    results: list[dict] = []
    for segment in segments:
        text = segment.text.strip()
        if text and float(segment.end) > float(segment.start):
            results.append({
                "start": max(0.0, round(float(segment.start), 3)),
                "end": round(float(segment.end), 3),
                "chinese": text,
                "vietnamese": "",
                "note": "",
            })
        if progress_callback:
            progress_callback()
    if not results:
        raise RuntimeError("Không nhận diện được lời thoại. Video có thể không có tiếng nói hoặc âm thanh quá nhỏ.")
    return results
