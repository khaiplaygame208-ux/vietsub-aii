import json
import re
import subprocess
import tempfile
import time
import threading
from pathlib import Path


class MediaError(RuntimeError):
    pass


def _run(command: list[str], timeout: int = 180, cancel_check=None,
         progress_callback=None, progress_duration: float | None = None) -> subprocess.CompletedProcess:
    try:
        # Capture stderr to disk; optionally parse FFmpeg's real -progress output from stdout.
        with tempfile.TemporaryFile(mode="w+b") as log_file:
            if progress_callback:
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log_file,
                                           text=True, encoding="utf-8", errors="replace", bufsize=1)
                def read_progress():
                    try:
                        assert process.stdout is not None
                        for line in process.stdout:
                            if line.startswith("out_time_ms=") and progress_duration and progress_duration > 0:
                                try:
                                    output_seconds = int(line.partition("=")[2].strip()) / 1_000_000
                                    fraction = max(0.0, min(0.99, output_seconds / progress_duration))
                                    progress_callback(fraction)
                                except (ValueError, OSError):
                                    continue
                    except Exception:
                        # The worker's main loop handles process errors and cancellation.
                        return
                reader = threading.Thread(target=read_progress, daemon=True)
                reader.start()
            else:
                process = subprocess.Popen(command, stdout=log_file, stderr=log_file)
                reader = None
            started = time.monotonic()
            while process.poll() is None:
                if cancel_check and cancel_check():
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)
                    if reader:
                        reader.join(timeout=2)
                    raise MediaError("Tác vụ đã bị hủy.")
                if time.monotonic() - started > timeout:
                    process.kill()
                    process.wait(timeout=5)
                    if reader:
                        reader.join(timeout=2)
                    raise MediaError("FFmpeg xử lý quá thời gian cho phép.")
                time.sleep(0.25)
            if reader:
                reader.join(timeout=3)
            log_file.seek(0, 2)
            length = log_file.tell()
            log_file.seek(max(0, length - 6000))
            output = log_file.read().decode("utf-8", errors="replace")
    except FileNotFoundError as exc:
        raise MediaError("Không tìm thấy FFmpeg/FFprobe. Hãy cài FFmpeg và thêm vào PATH.") from exc
    if process.returncode != 0:
        error = output[-1800:] or "Lỗi xử lý media"
        raise MediaError(error)
    return subprocess.CompletedProcess(command, process.returncode, stdout=output, stderr=output)


def probe_video(path: Path) -> dict:
    try:
        result = _run([
            "ffprobe", "-v", "error", "-show_entries",
            "format=duration,size:stream=codec_type,codec_name,width,height,duration",
            "-of", "json", str(path)
        ], timeout=30)
    except MediaError as exc:
        if str(exc).startswith("Không tìm thấy FFmpeg"):
            raise
        raise MediaError("Không đọc được video. Tệp có thể bị hỏng hoặc không đúng định dạng.") from exc
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise MediaError("FFprobe trả về dữ liệu không hợp lệ.") from exc
    streams = data.get("streams", [])
    video = next((stream for stream in streams if stream.get("codec_type") == "video"), None)
    audio = next((stream for stream in streams if stream.get("codec_type") == "audio"), None)
    if not video:
        raise MediaError("Tệp tải lên không chứa luồng video.")
    if not audio:
        raise MediaError("Video không có âm thanh để nhận diện lời thoại.")
    duration = float((data.get("format") or {}).get("duration") or video.get("duration") or 0)
    if duration <= 0:
        raise MediaError("Không xác định được thời lượng video.")
    return {"duration": duration, "video": video, "audio": audio, "format": data.get("format", {})}


def extract_audio(video_path: Path, output_path: Path, cancel_check=None) -> None:
    _run([
        "ffmpeg", "-y", "-i", str(video_path), "-map", "0:a:0", "-vn",
        "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(output_path)
    ], timeout=900, cancel_check=cancel_check)


def _escape_filter_path(path: Path) -> str:
    # The path is server-generated under the job directory; escape FFmpeg filter separators.
    value = path.resolve().as_posix()
    value = value.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
    value = value.replace(",", "\\,").replace("[", "\\[").replace("]", "\\]")
    return value


def hex_to_ass_color(value: str) -> str:
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", value):
        return "&H00FFFFFF"
    r, g, b = value[1:3], value[3:5], value[5:7]
    return f"&H00{b}{g}{r}".upper()


def render_burned_subtitles(video_path: Path, subtitle_path: Path, output_path: Path,
                            font_size: int = 24, font_family: str = "DejaVu Sans",
                            text_color: str = "#FFFFFF", background: str = "box",
                            position: str = "bottom", quality: str = "balanced",
                            duration: float | None = None, cancel_check=None,
                            progress_callback=None) -> None:
    subtitles = _escape_filter_path(subtitle_path)
    alignment = {"bottom": 2, "middle": 5, "top": 8}.get(position, 2)
    border_style = 3 if background == "box" else 1
    outline = 1 if background == "box" else 2
    allowed_fonts = {"DejaVu Sans", "Liberation Sans", "Noto Sans"}
    selected_font = font_family if font_family in allowed_fonts else "DejaVu Sans"
    force_style = (
        f"FontName={selected_font},FontSize={font_size},PrimaryColour={hex_to_ass_color(text_color)},"
        f"OutlineColour=&H80000000,BorderStyle={border_style},Outline={outline},Shadow=0,"
        f"Alignment={alignment},MarginV=28"
    )
    vf = f"subtitles='{subtitles}':force_style='{force_style}'"
    command = ["ffmpeg", "-y"]
    if progress_callback:
        command += ["-progress", "pipe:1", "-nostats"]
    quality_crf = {"compact": "26", "balanced": "22", "high": "18"}.get(quality, "22")
    command += ["-i", str(video_path), "-vf", vf, "-map", "0:v:0", "-map", "0:a?",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", quality_crf, "-c:a", "aac", "-b:a", "192k",
                "-movflags", "+faststart"]
    if duration:
        command += ["-t", str(duration)]
    command.append(str(output_path))
    _run(command, timeout=7200, cancel_check=cancel_check,
         progress_callback=progress_callback, progress_duration=duration)
