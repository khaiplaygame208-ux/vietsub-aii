from datetime import datetime, timezone
from threading import RLock
from typing import Any

_jobs: dict[str, dict[str, Any]] = {}
_lock = RLock()


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def create_job(job: dict[str, Any]) -> None:
    with _lock:
        _jobs[job["id"]] = job


def get_job(job_id: str) -> dict[str, Any] | None:
    with _lock:
        return _jobs.get(job_id)


def update_job(job_id: str, **fields: Any) -> None:
    with _lock:
        if job_id in _jobs:
            _jobs[job_id].update(fields)
            _jobs[job_id]["updated_at"] = utc_now()


def all_jobs() -> list[dict[str, Any]]:
    with _lock:
        return list(_jobs.values())
