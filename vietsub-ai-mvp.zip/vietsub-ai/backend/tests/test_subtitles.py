import unittest

from app.services.subtitles import to_srt, to_vtt
from app.services.translation import TranslationBatch, TranslationError, _parse_output


class SubtitleTests(unittest.TestCase):
    def setUp(self):
        self.segments = [{
            "start": 1.234,
            "end": 2.789,
            "chinese": "你好",
            "vietnamese": "Xin chào Việt Nam",
            "note": "",
        }]

    def test_srt_has_timestamps_and_vietnamese_diacritics(self):
        result = to_srt(self.segments)
        self.assertIn("00:00:01,234 --> 00:00:02,789", result)
        self.assertIn("Xin chào Việt Nam", result)

    def test_bilingual_subtitle_has_both_languages(self):
        result = to_srt(self.segments, bilingual=True)
        self.assertIn("你好", result)
        self.assertIn("Xin chào Việt Nam", result)
        self.assertIn("你好\nXin chào Việt Nam", result)

    def test_vtt_header_and_millisecond_separator(self):
        result = to_vtt(self.segments)
        self.assertTrue(result.startswith("WEBVTT\n\n"))
        self.assertIn("00:00:01.234 --> 00:00:02.789", result)


class TranslationSchemaTests(unittest.TestCase):
    def test_json_in_fenced_block_is_recovered(self):
        data = _parse_output('```json\n{"translations": []}\n```')
        self.assertEqual(data, {"translations": []})

    def test_translated_json_schema(self):
        data = {
            "translations": [{
                "index": 0, "start": 1.23, "end": 2.45, "chinese": "你好",
                "vietnamese": "Xin chào", "note": "",
            }]
        }
        parsed = TranslationBatch.model_validate(data)
        self.assertEqual(parsed.translations[0].vietnamese, "Xin chào")
        self.assertEqual(parsed.translations[0].chinese, "你好")

    def test_invalid_json_is_reported(self):
        with self.assertRaises(TranslationError):
            _parse_output('{not json}')


if __name__ == "__main__":
    unittest.main()
