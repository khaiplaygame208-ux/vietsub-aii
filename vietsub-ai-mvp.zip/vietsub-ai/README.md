# VietSub AI — MVP dịch video tiếng Trung sang tiếng Việt

MVP có mã nguồn chạy thật: **tải video → trích xuất âm thanh bằng FFmpeg → nhận diện lời thoại có mốc thời gian bằng faster-whisper → dịch theo lô bằng Gemini API → tạo SRT/VTT → ghép phụ đề vào MP4**. Có trình chỉnh sửa câu dịch/mốc thời gian và chức năng kết xuất lại video.

> Bản này tập trung vào chế độ phụ đề theo yêu cầu MVP. Chức năng lồng tiếng/TTS chưa được triển khai trong bản này; không có nút giả lập cho tính năng đó.

## Công nghệ

- Frontend: React + TypeScript + Vite + Tailwind CSS.
- Backend: FastAPI, tác vụ xử lý nền của FastAPI cho MVP.
- Nhận diện tiếng nói: `faster-whisper` chạy trên máy chủ (hỗ trợ tiếng Trung; model tải xuống khi chạy lần đầu).
- Dịch: Google Gemini API qua SDK chính thức `google-genai`.
- Video: FFmpeg/FFprobe, dùng filter `subtitles` để ghép phụ đề vào MP4.

Tên model Gemini mặc định là `gemini-3.8-flash`, có thể đổi bằng `GEMINI_MODEL`. Xem danh sách model đang được hỗ trợ và điều chỉnh khi Google cập nhật: https://ai.google.dev/gemini-api/docs/models

## Yêu cầu

- Python 3.11 hoặc 3.12 khuyến nghị.
- Node.js 20+ và npm.
- FFmpeg/FFprobe đã cài và có trong `PATH`. Bản Linux nên có thêm font DejaVu Sans để hiển thị dấu tiếng Việt: `sudo apt-get install ffmpeg fonts-dejavu-core`.
- Gemini API key từ https://aistudio.google.com/apikey.
- RAM: model Whisper `small` thường cần vài GB RAM; có thể đặt `WHISPER_MODEL=tiny` hoặc `base` trên máy yếu. Model được tải ở lần chạy đầu tiên.

## Chạy trên máy tính

Mở terminal ở thư mục `vietsub-ai`.

### 1. Cấu hình backend

```bash
cd backend
python -m venv .venv
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Cài thư viện và tạo file môi trường:

```bash
pip install -r requirements.txt
cp ../.env.example .env
```

Trên Windows có thể sao chép `.env.example` thủ công thành `backend/.env`. Sau đó chỉnh `backend/.env`, tối thiểu phải có:

```env
GEMINI_API_KEY=PASTE_YOUR_GEMINI_API_KEY
GEMINI_MODEL=gemini-3.8-flash
DATA_DIR=./data
MAX_UPLOAD_MB=500
JOB_RETENTION_HOURS=24
MAX_VIDEO_SECONDS=7200
WHISPER_MODEL=small
WHISPER_DEVICE=cpu
WHISPER_COMPUTE_TYPE=int8
CORS_ORIGINS=http://localhost:5173
```

**Không chia sẻ file `.env` và không đặt API key trong frontend.** `.env` được Git ignore.

Chạy backend khi đang ở `backend/`:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

API docs: http://localhost:8000/docs

### 2. Chạy frontend

Mở terminal thứ hai:

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Mở http://localhost:5173. Để mở trên điện thoại cùng Wi-Fi, dùng địa chỉ LAN của máy tính để truy cập Vite (ví dụ `http://192.168.1.10:5173`), đặt `VITE_API_BASE_URL=http://192.168.1.10:8000` trong `frontend/.env`, mở cổng trên firewall và đặt `CORS_ORIGINS` trong `backend/.env` thành origin frontend đó. Nếu backend chạy trên máy khác, thay URL tương ứng.

### 3. Quy trình dùng

1. Chọn video có lời thoại tiếng Trung, định dạng MP4, MOV, MKV, WEBM hoặc M4V.
2. Nhấn **Tải video lên máy chủ**; backend kiểm tra luồng video/âm thanh, dung lượng và thời lượng.
3. Chọn kiểu phụ đề và kiểu hiển thị, sau đó nhấn **Bắt đầu dịch bằng AI**.
4. Chờ các bước nhận diện, dịch, tạo phụ đề và kết xuất kết thúc. Tiến trình dựa trên trạng thái thật của backend, không phải animation giả.
5. Kiểm tra/chỉnh câu tiếng Việt và mốc thời gian; nhấn **Lưu và xuất lại MP4** nếu muốn áp dụng sửa đổi.
6. Tải MP4, SRT, VTT hoặc bản chép lời về máy.

## Chạy bằng Docker Compose

Nếu đã cài Docker Engine + Docker Compose, từ thư mục gốc dự án:

```bash
cp .env.example backend/.env
# sửa backend/.env, điền GEMINI_API_KEY trước khi chạy
mkdir -p backend/data
docker compose up --build -d
```

Truy cập `http://localhost:8080`. Khi triển khai lên máy chủ, đặt reverse proxy HTTPS phía trước cổng 8080; chỉ mở cổng web ra Internet và giữ cổng backend nội bộ. File video lưu ở `backend/data/`. Model Whisper được tải ở lần chạy đầu; máy chủ cần Internet outbound và đủ RAM/dung lượng. Để dùng bằng điện thoại ngoài mạng LAN, triển khai lên host có HTTPS/domain; không để API key trong frontend.

## API chính

- `GET /api/health`: tình trạng cấu hình API.
- `POST /api/jobs`: tải video multipart field `file`.
- `POST /api/jobs/{id}/translate`: xếp hàng dịch và kết xuất.
- `GET /api/jobs/{id}`: trạng thái và các đoạn phụ đề.
- `PUT /api/jobs/{id}/segments`: lưu bản dịch/mốc thời gian đã sửa.
- `POST /api/jobs/{id}/render`: kết xuất MP4 lại theo cấu hình.
- `POST /api/jobs/{id}/cancel`: yêu cầu hủy tác vụ; tiến trình FFmpeg có kiểm tra hủy định kỳ.
- `GET /api/jobs/{id}/files/{key}`: tải `video`, `srt`, `vtt`, `transcript` hoặc `json`.

## Cấu hình và giới hạn MVP

- Mặc định giới hạn file 500 MB, video 120 phút, lưu tệp tối đa 24 giờ; chỉnh trong `backend/.env`.
- Tệp làm việc nằm trong `backend/data/`. Dọn dẹp theo chu kỳ một giờ và khi backend khởi động; thời hạn được tính từ lần cập nhật gần nhất.
- Tác vụ/trạng thái hiện lưu trong RAM và tác vụ nền của một tiến trình FastAPI. Đây là cấu hình MVP dành cho máy đơn; khi triển khai dịch vụ nhiều người dùng/đa worker, hãy thay bằng Redis + Celery/RQ, cơ sở dữ liệu, xác thực người dùng, giới hạn tốc độ và lưu trữ đối tượng.
- Whisper model tải lần đầu có thể lâu. Với CPU yếu, đặt `WHISPER_MODEL=tiny` hoặc `base`; nhận diện có thể kém chính xác hơn.
- Video phải có âm thanh; phiên bản này chưa sử dụng phụ đề có sẵn làm đầu vào dự phòng và chưa có tách giọng khỏi nhạc nền.
- `faster-whisper` xử lý lời nói, Gemini xử lý dịch. Chất lượng nhận diện phụ thuộc chất lượng âm thanh và có thể cần người dùng kiểm tra/chỉnh phụ đề.
- Font kết xuất mặc định `DejaVu Sans`; có hỗ trợ dấu tiếng Việt. Có thể chọn DejaVu Sans, Liberation Sans hoặc Noto Sans (font tương ứng phải được cài ở máy chủ). Chất lượng MP4 gồm ba mức CRF: file nhỏ, cân bằng và chất lượng cao. Nếu FFmpeg không có filter `subtitles`/libass, cần cài bản FFmpeg có libass.
- Dữ liệu tác vụ là bộ nhớ tạm. Khởi động lại server sẽ làm mất danh sách tác vụ trong RAM dù dữ liệu tệp có thể vẫn còn; cấu hình này cần được thay trước khi chạy production.
- Đây chưa phải triển khai production. Cần reverse proxy có HTTPS, xác thực, giới hạn concurrency, quota, giám sát và chính sách riêng tư phù hợp trước khi mở công khai.

## Kiểm thử

### Smoke test backend

```bash
cd backend
python -m compileall app
python -m unittest discover -s tests -v
```

Mở http://localhost:8000/docs để kiểm tra API. Trước khi chạy pipeline thật, xác nhận `GET /api/health` có `gemini_configured: true` và máy chủ gọi được `ffmpeg -version`, `ffprobe -version`.

### Checklist thủ công

- Video MP4 có lời thoại Quan thoại rõ.
- Clip có nhiều người nói; kiểm tra mốc thời gian và chỉnh sửa thủ công.
- Video có nhạc nền: bản MVP vẫn nhận diện trên toàn bộ track, không hứa tách nhạc khỏi giọng.
- Video không có âm thanh hoặc không có lời nói: phải báo lỗi nhận diện.
- Video có phụ đề tiếng Trung sẵn: bản hiện tại chưa đọc track subtitle làm đầu vào.
- Video dài hoặc vượt giới hạn: API phải từ chối trước khi xử lý nặng.
- Tắt/bỏ `GEMINI_API_KEY`: backend trả thông báo cấu hình, không tạo bản dịch giả.
- API Gemini lỗi/JSON sai: pipeline retry cục bộ tối đa 3 lần rồi báo lỗi tác vụ.
- Tải nhiều video: mỗi video có mã tác vụ riêng; lưu ý MVP chưa giới hạn hàng đợi/concurrency production.
- Hủy trong khi xử lý: yêu cầu hủy được kiểm tra giữa các bước và bởi tiến trình FFmpeg; yêu cầu hủy trong một lần gọi model có thể chỉ được nhận tại ranh giới bước/lô kế tiếp.

## Lộ trình tiếp theo

1. Bổ sung TTS tiếng Việt và ghép giọng theo timeline, ưu tiên Google Cloud Text-to-Speech hoặc Gemini TTS sau khi xác minh model/quota ở khu vực triển khai.
2. Tách giọng và nhạc bằng mô hình source separation, chỉ bật khi dịch vụ được cấu hình.
3. Hàng đợi Redis/Celery, lưu trữ S3/GCS, xác thực tài khoản và giới hạn tài nguyên.
