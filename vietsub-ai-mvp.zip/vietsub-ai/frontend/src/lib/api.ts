const API_BASE = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/$/, '')

export type Segment = { start: number; end: number; chinese: string; vietnamese: string; note: string }
export type JobStatus = {
  job_id: string
  filename?: string | null
  status: 'uploaded' | 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled'
  stage: string
  progress: number
  message: string
  error?: string | null
  duration?: number | null
  segments?: Segment[] | null
  outputs?: Record<string, string>
}
export type RenderOptions = {
  bilingual: boolean
  font_size: number
  font_family: 'DejaVu Sans' | 'Liberation Sans' | 'Noto Sans'
  text_color: string
  background: 'box' | 'outline'
  position: 'bottom' | 'middle' | 'top'
  quality: 'compact' | 'balanced' | 'high'
}

export const apiUrl = (path: string) => `${API_BASE}${path}`

export async function health() {
  const response = await fetch(apiUrl('/api/health'))
  if (!response.ok) throw new Error('Không kết nối được máy chủ.')
  return response.json() as Promise<{ ok: boolean; gemini_configured: boolean; gemini_model: string; max_upload_mb: number; retention_hours: number }>
}

export function uploadVideo(file: File, onProgress: (progress: number) => void): Promise<{ job_id: string; filename: string; size_bytes: number; duration: number; status: string }> {
  return new Promise((resolve, reject) => {
    const form = new FormData()
    form.append('file', file)
    const xhr = new XMLHttpRequest()
    xhr.open('POST', apiUrl('/api/jobs'))
    xhr.upload.onprogress = event => {
      if (event.lengthComputable) onProgress(Math.min(100, Math.round((event.loaded / event.total) * 100)))
    }
    xhr.onload = () => {
      let data: any = {}
      try { data = JSON.parse(xhr.responseText) } catch { /* handled below */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data)
      else reject(new Error(data.detail || `Tải video thất bại (${xhr.status}).`))
    }
    xhr.onerror = () => reject(new Error('Lỗi mạng khi tải video.'))
    xhr.onabort = () => reject(new Error('Đã hủy tải lên.'))
    xhr.send(form)
  })
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(apiUrl(path), {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.detail || `Yêu cầu thất bại (${response.status}).`)
  return data as T
}

export const startTranslation = (id: string, options: RenderOptions) => request(`/api/jobs/${id}/translate`, { method: 'POST', body: JSON.stringify(options) })
export const getStatus = (id: string) => request<JobStatus>(`/api/jobs/${id}`)
export const cancelJob = (id: string) => request(`/api/jobs/${id}/cancel`, { method: 'POST' })
export const saveSegments = (id: string, segments: Segment[], options: RenderOptions) => request(`/api/jobs/${id}/segments`, { method: 'PUT', body: JSON.stringify({ segments, ...options }) })
export const rerender = (id: string, options: RenderOptions) => request(`/api/jobs/${id}/render`, { method: 'POST', body: JSON.stringify(options) })
export const fileUrl = (id: string, kind: string) => apiUrl(`/api/jobs/${id}/files/${kind}`)
