import { FileVideo, UploadCloud, X } from 'lucide-react'
import { useRef, useState } from 'react'

type Props = { file: File | null; onChoose: (file: File | null) => void; disabled?: boolean; maxMb: number }
const supported = ['.mp4', '.mov', '.mkv', '.webm', '.m4v']

export default function UploadPanel({ file, onChoose, disabled, maxMb }: Props) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)
  const [error, setError] = useState('')
  const acceptFile = (candidate?: File) => {
    if (!candidate) return
    const ext = `.${candidate.name.split('.').pop()?.toLowerCase() || ''}`
    if (!supported.includes(ext)) { setError('Định dạng chưa được hỗ trợ. Hãy chọn MP4, MOV, MKV, WEBM hoặc M4V.'); return }
    if (candidate.size > maxMb * 1024 * 1024) { setError(`Tệp vượt quá giới hạn ${maxMb} MB.`); return }
    setError('')
    onChoose(candidate)
  }
  const prettySize = (bytes: number) => bytes > 1024 ** 3 ? `${(bytes / 1024 ** 3).toFixed(2)} GB` : `${(bytes / 1024 ** 2).toFixed(1)} MB`
  return <div>
    <input ref={inputRef} type="file" accept={supported.join(',')} className="hidden" onChange={e => acceptFile(e.target.files?.[0])} disabled={disabled} />
    {!file ? <button type="button" disabled={disabled} onClick={() => inputRef.current?.click()}
      onDragEnter={e => { e.preventDefault(); setDragging(true) }} onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={e => { e.preventDefault(); setDragging(false) }} onDrop={e => { e.preventDefault(); setDragging(false); acceptFile(e.dataTransfer.files?.[0]) }}
      className={`dropzone ${dragging ? 'dropzone-active' : ''}`}>
      <span className="upload-icon"><UploadCloud size={26} /></span>
      <strong>Kéo thả video vào đây</strong>
      <span className="muted">hoặc nhấn để chọn file từ thiết bị</span>
      <span className="format-pills"><i>MP4</i><i>MOV</i><i>MKV</i><i>WEBM</i><i>Tối đa {maxMb} MB</i></span>
    </button> : <div className="file-selected">
      <div className="file-icon"><FileVideo size={24} /></div>
      <div className="file-info"><strong title={file.name}>{file.name}</strong><span>{prettySize(file.size)}</span></div>
      <button className="icon-button" title="Bỏ chọn video" disabled={disabled} onClick={() => { onChoose(null); if (inputRef.current) inputRef.current.value = '' }}><X size={18} /></button>
    </div>}
    {error && <p className="field-error">{error}</p>}
  </div>
}
