import { useEffect, useMemo, useState } from 'react'
import {
  ArrowDownToLine, AudioLines, Check, ChevronDown, CircleAlert, Clapperboard,
  FileText, Languages, LoaderCircle, Play, RotateCcw, Settings2, ShieldCheck,
  Sparkles, Subtitles, UploadCloud, WandSparkles, X,
} from 'lucide-react'
import UploadPanel from './components/UploadPanel'
import {
  cancelJob, fileUrl, getStatus, health, JobStatus, RenderOptions, rerender,
  saveSegments, Segment, startTranslation, uploadVideo,
} from './lib/api'

const DEFAULT_OPTIONS: RenderOptions = {
  bilingual: false, font_size: 24, font_family: 'DejaVu Sans', text_color: '#FFFFFF', background: 'box', position: 'bottom', quality: 'balanced',
}
const STAGES = [
  { key: 'extract_audio', label: 'Trích xuất âm thanh' },
  { key: 'transcribe', label: 'Nhận diện tiếng Trung' },
  { key: 'translate', label: 'Dịch bằng Gemini' },
  { key: 'subtitles', label: 'Tạo phụ đề' },
  { key: 'render', label: 'Kết xuất MP4' },
]
const fmtDuration = (seconds?: number | null) => {
  if (!seconds || !Number.isFinite(seconds)) return '—'
  const m = Math.floor(seconds / 60), s = Math.floor(seconds % 60)
  return `${m}:${String(s).padStart(2, '0')}`
}
const fmtTime = (seconds: number) => {
  const m = Math.floor(seconds / 60), s = seconds % 60
  return `${String(m).padStart(2, '0')}:${s.toFixed(2).padStart(5, '0')}`
}

export default function App() {
  const [file, setFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState('')
  const [jobId, setJobId] = useState('')
  const [status, setStatus] = useState<JobStatus | null>(null)
  const [segments, setSegments] = useState<Segment[]>([])
  const [options, setOptions] = useState<RenderOptions>(DEFAULT_OPTIONS)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [busy, setBusy] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [apiInfo, setApiInfo] = useState<{ gemini_configured: boolean; gemini_model: string; max_upload_mb: number; retention_hours: number } | null>(null)
  const [showSettings, setShowSettings] = useState(true)
  const working = status?.status === 'queued' || status?.status === 'processing'
  const jobProgress = status?.status === 'completed' ? 100 : status?.progress || 0

  useEffect(() => {
    health().then(setApiInfo).catch(() => setError('Không kết nối được backend. Hãy khởi động FastAPI tại http://localhost:8000.'))
  }, [])

  useEffect(() => {
    if (!file) { setPreviewUrl(''); return }
    const url = URL.createObjectURL(file)
    setPreviewUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [file])

  useEffect(() => {
    if (!jobId || !working) return
    let live = true
    const poll = async () => {
      try {
        const next = await getStatus(jobId)
        if (!live) return
        setStatus(next)
        if (next.segments) setSegments(next.segments)
        if (next.status === 'failed') setError(next.error || next.message || 'Tác vụ thất bại.')
        if (next.status === 'completed' || next.status === 'failed' || next.status === 'cancelled') return
      } catch (e) {
        if (live) setError(e instanceof Error ? e.message : 'Không thể kiểm tra tiến trình.')
      }
    }
    void poll()
    const timer = window.setInterval(() => void poll(), 1300)
    return () => { live = false; window.clearInterval(timer) }
  }, [jobId, working])

  useEffect(() => {
    if (status?.segments && status.status === 'completed') setSegments(status.segments)
  }, [status?.status, status?.segments])

  const videoSrc = useMemo(() => jobId && status?.status === 'completed' ? fileUrl(jobId, 'video') : previewUrl, [jobId, status?.status, previewUrl])

  const chooseFile = (next: File | null) => {
    setFile(next); setJobId(''); setStatus(null); setSegments([]); setError(''); setUploadProgress(0)
  }

  const upload = async () => {
    if (!file) return
    setBusy(true); setError(''); setUploadProgress(0)
    try {
      const result = await uploadVideo(file, setUploadProgress)
      setJobId(result.job_id)
      const next = await getStatus(result.job_id)
      setStatus(next)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Tải video thất bại.')
    } finally { setBusy(false) }
  }

  const translate = async () => {
    if (!jobId) return
    setBusy(true); setError('')
    try {
      await startTranslation(jobId, options)
      setStatus({ job_id: jobId, status: 'queued', stage: 'queued', progress: 2, message: 'Đang xếp hàng xử lý…' })
    } catch (e) { setError(e instanceof Error ? e.message : 'Không thể bắt đầu dịch.') }
    finally { setBusy(false) }
  }

  const updateSegment = (index: number, patch: Partial<Segment>) => {
    setSegments(current => current.map((segment, i) => i === index ? { ...segment, ...patch } : segment))
  }

  const saveAndRender = async () => {
    if (!jobId) return
    setSaving(true); setError('')
    try {
      await saveSegments(jobId, segments, options)
      await rerender(jobId, options)
      setStatus(current => current ? { ...current, status: 'queued', stage: 'queued', progress: 82, message: 'Đang kết xuất lại video…' } : current)
    } catch (e) { setError(e instanceof Error ? e.message : 'Không thể lưu phụ đề.') }
    finally { setSaving(false) }
  }

  const cancel = async () => {
    if (!jobId) return
    try { await cancelJob(jobId); setStatus(current => current ? { ...current, message: 'Đã gửi yêu cầu hủy…' } : current) }
    catch (e) { setError(e instanceof Error ? e.message : 'Không thể hủy tác vụ.') }
  }

  const clearProject = () => {
    setFile(null); setJobId(''); setStatus(null); setSegments([]); setError(''); setUploadProgress(0); setOptions(DEFAULT_OPTIONS)
  }

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#top" aria-label="VietSub AI trang chủ">
        <span className="brand-mark"><Languages size={22} strokeWidth={2.5} /></span>
        <span>VietSub <b>AI</b></span>
      </a>
      <div className="topbar-right"><span className="secure-tag"><ShieldCheck size={14} /> API key bảo mật ở máy chủ</span><span className="version-tag">MVP 0.1</span></div>
    </header>

    <main id="top" className="main-layout">
      <section className="hero">
        <div className="eyebrow"><Sparkles size={14} /> BIÊN DỊCH VIDEO BẰNG AI</div>
        <h1>Dịch video tiếng Trung<br /><span>sang tiếng Việt.</span></h1>
        <p className="hero-copy">Tạo phụ đề tự động, chỉnh sửa câu dịch và xuất video MP4 — trong một quy trình liền mạch.</p>
        <div className="feature-row">
          <span><AudioLines size={16} /> Nhận diện lời thoại</span>
          <span><WandSparkles size={16} /> Gemini dịch thuật</span>
          <span><Subtitles size={16} /> SRT · VTT · MP4</span>
        </div>
      </section>

      <div className="workspace-grid">
        <section className="panel upload-panel">
          <div className="panel-heading">
            <div className="heading-icon"><Clapperboard size={18} /></div>
            <div><h2>01. Video nguồn</h2><p>Tải lên video cần dịch</p></div>
            {status?.duration ? <span className="duration-pill">{fmtDuration(status.duration)}</span> : null}
          </div>

          <UploadPanel file={file} onChoose={chooseFile} disabled={busy || working} maxMb={apiInfo?.max_upload_mb || 500} />

          {file && <div className="preview-wrap">
            <div className="preview-header"><span>XEM TRƯỚC</span>{status?.filename ? <span>{status.filename}</span> : <span>Video chưa tải lên</span>}</div>
            {videoSrc ? <video key={videoSrc} className="video-player" src={videoSrc} controls playsInline preload="metadata" /> : <div className="video-placeholder"><Play size={25} /><span>Bản xem trước video</span></div>}
          </div>}

          {file && !jobId && <button className="button button-primary button-full" onClick={upload} disabled={busy}>
            {busy ? <><LoaderCircle className="spin" size={18} /> Đang tải lên {uploadProgress}%</> : <><UploadCloud size={18} /> Tải video lên máy chủ</>}
          </button>}
          {file && !jobId && busy && <div className="upload-track"><span style={{ width: `${uploadProgress}%` }} /></div>}
          {jobId && status?.status === 'uploaded' && <div className="ready-strip"><Check size={16} /><span>Video đã tải lên, sẵn sàng xử lý.</span></div>}

          <div className="privacy-note"><ShieldCheck size={15} /><span>Tệp được lưu tạm trên máy chủ và tự động xóa sau {apiInfo?.retention_hours || 24} giờ theo cấu hình.</span></div>
        </section>

        <section className="panel settings-panel">
          <button className="panel-heading heading-button" onClick={() => setShowSettings(v => !v)} aria-expanded={showSettings}>
            <div className="heading-icon"><Settings2 size={18} /></div>
            <div className="heading-title"><h2>02. Cài đặt phụ đề</h2><p>Tùy chỉnh trước khi kết xuất</p></div>
            <ChevronDown className={`collapse-chevron ${showSettings ? 'is-open' : ''}`} size={18} />
          </button>
          {showSettings && <div className="settings-body">
            <div className="setting-group">
              <label className="field-label">Ngôn ngữ đầu ra</label>
              <div className="language-pair"><span className="language-chip"><span className="flag">🇨🇳</span> Tiếng Trung</span><span className="arrow">→</span><span className="language-chip target"><span className="flag">🇻🇳</span> Tiếng Việt</span></div>
              <p className="hint">Nhận diện bằng faster-whisper · Dịch bằng {apiInfo?.gemini_model || 'Gemini API'}</p>
            </div>
            <div className="setting-group">
              <label className="field-label">Kiểu phụ đề</label>
              <div className="choice-grid">
                <button className={`choice-card ${!options.bilingual ? 'selected' : ''}`} onClick={() => setOptions(o => ({ ...o, bilingual: false }))}>
                  <span className="choice-check">{!options.bilingual && <Check size={12} />}</span><Subtitles size={19} /><strong>Chỉ tiếng Việt</strong><small>Dễ đọc, gọn màn hình</small>
                </button>
                <button className={`choice-card ${options.bilingual ? 'selected' : ''}`} onClick={() => setOptions(o => ({ ...o, bilingual: true }))}>
                  <span className="choice-check">{options.bilingual && <Check size={12} />}</span><Languages size={19} /><strong>Trung – Việt</strong><small>Hai ngôn ngữ cùng lúc</small>
                </button>
              </div>
            </div>
            <div className="setting-group">
              <div className="field-label-row"><label className="field-label" htmlFor="font-size">Kích thước chữ</label><span className="value-pill">{options.font_size}px</span></div>
              <input id="font-size" className="range-input" type="range" min="16" max="42" step="2" value={options.font_size} onChange={e => setOptions(o => ({ ...o, font_size: Number(e.target.value) }))} />
              <div className="range-labels"><span>Nhỏ</span><span>Lớn</span></div>
            </div>
            <div className="setting-group color-position-grid">
              <div><label className="field-label" htmlFor="sub-color">Màu chữ</label><div className="color-field"><input id="sub-color" type="color" value={options.text_color} onChange={e => setOptions(o => ({ ...o, text_color: e.target.value }))} /><span>{options.text_color.toUpperCase()}</span></div></div>
              <div><label className="field-label" htmlFor="sub-position">Vị trí phụ đề</label><select id="sub-position" className="select-field" value={options.position} onChange={e => setOptions(o => ({ ...o, position: e.target.value as RenderOptions['position'] }))}><option value="bottom">Dưới cùng</option><option value="middle">Ở giữa</option><option value="top">Phía trên</option></select></div>
            </div>
            <div className="setting-group color-position-grid">
              <div><label className="field-label" htmlFor="sub-font">Font chữ</label><select id="sub-font" className="select-field" value={options.font_family} onChange={e => setOptions(o => ({ ...o, font_family: e.target.value as RenderOptions['font_family'] }))}><option value="DejaVu Sans">DejaVu Sans</option><option value="Liberation Sans">Liberation Sans</option><option value="Noto Sans">Noto Sans</option></select></div>
              <div><label className="field-label" htmlFor="sub-quality">Chất lượng MP4</label><select id="sub-quality" className="select-field" value={options.quality} onChange={e => setOptions(o => ({ ...o, quality: e.target.value as RenderOptions['quality'] }))}><option value="compact">Nhẹ, file nhỏ</option><option value="balanced">Cân bằng</option><option value="high">Cao, file lớn hơn</option></select></div>
            </div>
            <div className="setting-group">
              <label className="field-label">Nền chữ</label>
              <div className="segmented"><button className={options.background === 'box' ? 'active' : ''} onClick={() => setOptions(o => ({ ...o, background: 'box' }))}>Nền tối</button><button className={options.background === 'outline' ? 'active' : ''} onClick={() => setOptions(o => ({ ...o, background: 'outline' }))}>Viền chữ</button></div>
            </div>
            <div className="subtitle-sample" style={{ color: options.text_color, fontSize: `${Math.min(options.font_size, 28)}px` }}>
              <span className={options.background === 'box' ? 'sample-box' : 'sample-outline'}>Xin chào! Đây là phụ đề tiếng Việt.</span>
            </div>
          </div>}
          <div className="gemini-info"><span className={`status-dot ${apiInfo?.gemini_configured ? 'online' : 'offline'}`} />
            <div><strong>{apiInfo?.gemini_configured ? 'Gemini API đã cấu hình' : 'Cần cấu hình Gemini API'}</strong><p>{apiInfo?.gemini_configured ? 'Sẵn sàng dịch nội dung sau khi nhận diện.' : 'Điền GEMINI_API_KEY trong backend/.env để bắt đầu.'}</p></div>
          </div>
        </section>
      </div>

      <section className="panel process-panel">
        <div className="process-top">
          <div className="panel-heading no-bottom">
            <div className="heading-icon heading-icon-purple"><WandSparkles size={18} /></div>
            <div><h2>03. Xử lý video</h2><p>Tiến trình cập nhật từ backend</p></div>
          </div>
          {working && <button className="button button-ghost button-small" onClick={cancel}><X size={15} /> Hủy tác vụ</button>}
        </div>
        <div className="big-progress-row"><div><strong>{working ? 'Đang xử lý video…' : status?.status === 'completed' ? 'Video đã sẵn sàng!' : 'Sẵn sàng để bắt đầu'}</strong><p>{status?.message || 'Sau khi tải lên, nhấn bắt đầu dịch để xử lý video thực tế.'}</p></div><span className="progress-number">{jobId && status ? `${jobProgress}%` : '—'}</span></div>
        <div className="progress-track"><span style={{ width: `${jobId ? jobProgress : 0}%` }} /></div>
        <div className="steps-grid">
          {STAGES.map((stage, index) => {
            const stageIndex = STAGES.findIndex(item => item.key === status?.stage)
            const isDone = status?.status === 'completed' || (stageIndex >= 0 && index < stageIndex)
            const isActive = working && status?.stage === stage.key
            return <div className={`process-step ${isDone ? 'done' : ''} ${isActive ? 'active' : ''}`} key={stage.key}>
              <span className="step-icon">{isDone ? <Check size={15} /> : isActive ? <LoaderCircle className="spin" size={15} /> : <span>{String(index + 1).padStart(2, '0')}</span>}</span><span>{stage.label}</span>
            </div>
          })}
        </div>
        {jobId && status?.status === 'uploaded' && <button className="button button-primary button-full start-button" onClick={translate} disabled={busy || !apiInfo?.gemini_configured}>
          {busy ? <><LoaderCircle className="spin" size={17} /> Đang bắt đầu…</> : <>Bắt đầu dịch bằng AI <Sparkles size={17} /></>}
        </button>}
        {!apiInfo?.gemini_configured && jobId && status?.status === 'uploaded' && <div className="inline-warning"><CircleAlert size={17} /><span>Cần API key từ <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">Google AI Studio</a>. Không có kết quả giả lập.</span></div>}
        {status?.status === 'failed' && <div className="inline-error"><CircleAlert size={17} /><span>{status.error || error || 'Tác vụ thất bại.'}</span><button className="button button-secondary button-small" onClick={translate}>Thử lại</button></div>}
        {status?.status === 'cancelled' && <div className="inline-warning"><CircleAlert size={17} /><span>Tác vụ đã bị hủy.</span><button className="button button-secondary button-small" onClick={translate}>Chạy lại</button></div>}
        {error && status?.status !== 'failed' && <div className="inline-error"><CircleAlert size={17} /><span>{error}</span><button className="clear-error" onClick={() => setError('')} aria-label="Đóng lỗi"><X size={15} /></button></div>}
      </section>

      {status?.status === 'completed' && jobId && <section className="panel results-panel">
        <div className="results-header"><div className="panel-heading no-bottom"><div className="heading-icon heading-icon-green"><Check size={18} /></div><div><h2>04. Kết quả và chỉnh sửa</h2><p>{segments.length} đoạn phụ đề · Có thể sửa trước khi xuất lại</p></div></div><button className="button button-secondary button-small" onClick={clearProject}><RotateCcw size={15} /> Dự án mới</button></div>
        <div className="download-grid">
          <a className="download-card primary-download" href={fileUrl(jobId, 'video')} download><span className="download-icon"><Clapperboard size={21} /></span><span><strong>Video MP4</strong><small>Đã ghép phụ đề vào hình ảnh</small></span><ArrowDownToLine size={18} /></a>
          <a className="download-card" href={fileUrl(jobId, 'srt')} download><span className="download-icon"><FileText size={21} /></span><span><strong>Phụ đề SRT</strong><small>Dùng cho trình phát video</small></span><ArrowDownToLine size={18} /></a>
          <a className="download-card" href={fileUrl(jobId, 'vtt')} download><span className="download-icon"><Subtitles size={21} /></span><span><strong>Phụ đề VTT</strong><small>Dùng cho web / HTML5</small></span><ArrowDownToLine size={18} /></a>
          <a className="download-card" href={fileUrl(jobId, 'transcript')} download><span className="download-icon"><FileText size={21} /></span><span><strong>Bản chép lời</strong><small>Tiếng Trung và bản dịch</small></span><ArrowDownToLine size={18} /></a>
        </div>
        <div className="editor-heading"><div><h3>Trình chỉnh sửa phụ đề</h3><p>Thay đổi nội dung hoặc thời gian rồi lưu và kết xuất lại MP4.</p></div><span className="edit-count">{segments.length} dòng</span></div>
        <div className="editor-table-wrap">
          <table className="editor-table"><thead><tr><th>Thời gian</th><th>Tiếng Trung</th><th>Tiếng Việt</th></tr></thead>
            <tbody>{segments.map((segment, index) => <tr key={index}>
              <td className="time-cell"><label><span>Bắt đầu (giây)</span><input type="number" min="0" step="0.1" value={segment.start} onChange={e => updateSegment(index, { start: Number(e.target.value) })} /></label><label><span>Kết thúc (giây)</span><input type="number" min={segment.start + 0.1} step="0.1" value={segment.end} onChange={e => updateSegment(index, { end: Number(e.target.value) })} /></label><button className="play-segment" title={`Phát từ ${fmtTime(segment.start)}`} onClick={() => { const player = document.querySelector<HTMLVideoElement>('.video-player'); if (player) { player.currentTime = segment.start; void player.play() } }}><Play size={12} /> {fmtTime(segment.start)}</button></td>
              <td><textarea aria-label={`Tiếng Trung dòng ${index + 1}`} value={segment.chinese} rows={2} onChange={e => updateSegment(index, { chinese: e.target.value })} /></td>
              <td><textarea aria-label={`Tiếng Việt dòng ${index + 1}`} value={segment.vietnamese} rows={2} onChange={e => updateSegment(index, { vietnamese: e.target.value })} /></td>
            </tr>)}</tbody>
          </table>
        </div>
        <div className="editor-actions"><span className="muted"><ShieldCheck size={14} /> Bản chỉnh sửa chỉ áp dụng cho tác vụ này</span><button className="button button-primary" onClick={saveAndRender} disabled={saving || working || !segments.length}>{saving || working ? <><LoaderCircle className="spin" size={16} /> Đang kết xuất…</> : <><Check size={16} /> Lưu và xuất lại MP4</>}</button></div>
      </section>}

      <footer className="footer"><span>© 2026 VietSub AI</span><span><span className="footer-dot" /> Backend xử lý thật · Không tạo dữ liệu giả</span><span className="footer-links"><a href="https://ai.google.dev/gemini-api/docs" target="_blank" rel="noreferrer">Gemini API</a><a href="https://ffmpeg.org/documentation.html" target="_blank" rel="noreferrer">FFmpeg</a></span></footer>
    </main>
  </div>
}
